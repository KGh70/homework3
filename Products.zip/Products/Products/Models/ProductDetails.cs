﻿using System.ComponentModel.DataAnnotations;

namespace Products.Models
{
    public class ProductDetails
    {
        [Key]
        public int Id { get; set; }
        public int Products_Id { get; set; }

        public string Images { get; set; }

        public double Price { get; set; }

        public int Qty { get; set; }

        public string Color { get; set; }

    }
}
