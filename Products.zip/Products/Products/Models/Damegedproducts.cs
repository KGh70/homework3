﻿using System.ComponentModel.DataAnnotations;

namespace Products.Models
{
    public class Damegedproducts
    {
        [Key]
        public int Id { get; set; }
        public int Qty { get; set; }
        public int ProductId { get; set; }
    }
}
