﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Products.Data;
using Products.Models;
using System.Diagnostics;

namespace Products.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public HomeController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;

        }

        

        public JsonResult GetData(int id)
        {
            var product = _context.Products.SingleOrDefault(p => p.Id == id);

            if (product != null)
            {
                return Json(product);
            }
            else 
            {
                return Json(null);
            }
        }

        [Route("create")]
        public IActionResult Create(Product p)
        {

            if (ModelState.IsValid)
            {
                _context.Products.Add(p);
                _context.SaveChanges();
                TempData["Add"] = "تمت الإضافة بنجاح";
                return RedirectToAction("Index");

            }
            TempData["Add"] = "لم تتم الإضافة يرجى التأكد من صحة المدخلات";


            var products = _context.Products.ToList();
            return View("index", products);


        }

        public IActionResult CreateDetails(ProductDetails productDetails, IFormFile photo)
        {



            if (photo == null || photo.Length == 0)
            {
                return Content("File Not Selected");
            }

            var path = Path.Combine(_webHostEnvironment.WebRootPath, "img", photo.FileName);

            using (FileStream stream = new FileStream(path, FileMode.Create))
            {
                photo.CopyTo(stream);
                stream.Close();
            }

            productDetails.Images = photo.FileName;
            _context.ProductDetails.Add(productDetails);
            _context.SaveChanges();
            return RedirectToAction("ProductsDetails");
        }
        public IActionResult ProductsDetails()
        {
            var ProductDetails = _context.ProductDetails.Join(

                _context.Products,

                productsdetails => productsdetails.Products_Id,
                product => product.Id,

                (productsdetails, product) => new
                {
                    id = productsdetails.Id,
                    name = product.Name,
                    color = productsdetails.Color,
                    price = productsdetails.Price,
                    qty = productsdetails.Qty,
                    img = productsdetails.Images,
                }



                ).ToList();

            var prodcts = _context.Products.ToList();

            ViewBag.products = prodcts;
            ViewBag.ProductDetails = ProductDetails;
            return View();
        }


        [HttpPost]
        public IActionResult UpdateDetails(ProductDetails model, IFormFile newPhoto)
        {
            var existingDetail = _context.ProductDetails.Find(model.Id);
            if (existingDetail != null)
            {
                existingDetail.Products_Id = model.Products_Id; // Assuming you want to allow changing the linked product
                existingDetail.Price = model.Price;
                existingDetail.Qty = model.Qty;
                existingDetail.Color = model.Color;

                // Handle photo update
                if (newPhoto != null && newPhoto.Length > 0)
                {
                    var path = Path.Combine(_webHostEnvironment.WebRootPath, "img", newPhoto.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        newPhoto.CopyTo(stream);
                    }
                    existingDetail.Images = newPhoto.FileName;  // Update the path to the new image
                }

                _context.Update(existingDetail);
                _context.SaveChanges();
                TempData["UpdateMessage"] = "Details updated successfully.";
            }
            else
            {
                TempData["UpdateMessage"] = "Detail not found.";
            }

            return RedirectToAction("ProductsDetails");
        }


        public IActionResult DeleteDetails(int id)
        {
            var detail = _context.ProductDetails.SingleOrDefault(p => p.Id == id);
            if (detail != null)
            {
                _context.ProductDetails.Remove(detail);
                _context.SaveChanges();
                TempData["DeleteMessage"] = "تم الحذف بنجاح";
            }
            else
            {
                TempData["DeleteMessage"] = "فشل الحذف";
            }
            return RedirectToAction("ProductsDetails");
        }

        public IActionResult GetProductDetailData(int id)
        {
            var productDetail = _context.ProductDetails.Find(id);
            if (productDetail != null)
            {
                return Json(new
                {
                    id = productDetail.Id,
                    products_Id = productDetail.Products_Id,
                    price = productDetail.Price,
                    qty = productDetail.Qty,
                    color = productDetail.Color
                });
            }
            else
            {
                return Json(null);
            }
        }




        public IActionResult Index()
        {
            var products = _context.Products.ToList();  //Read
            ViewBag.Products = products;
            return View(products);
        }

        [Route("test")]
        public void Test()
        {
            Console.WriteLine("Success");
        }


        [HttpPost]
        public JsonResult Delete(int record_no)
        {
            var productdel = _context.Products.SingleOrDefault(p => p.Id == record_no);//serch on record 

            if (productdel != null)
            {
                _context.Products.Remove(productdel);
                _context.SaveChanges();
                TempData["del"] = true;
            }

            else
            {
                TempData["del"] = false;
            }

            return Json("Ok");

        }
        public IActionResult Update(Product product)
        {
            if (ModelState.IsValid)
            {
                _context.Products.Update(product);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
        public IActionResult Edit(int record_no)
        {
            var Product = _context.Products.SingleOrDefault(x => x.Id == record_no);

            return View(Product);

        }



        public IActionResult AddDemag(Damegedproducts damege)
        {

            _context.Add(damege);
            _context.SaveChanges();

            return RedirectToAction("Demag");
        }
        public IActionResult Demag()
        {   
            ViewBag.Username = HttpContext.Session.GetString("userdata");
            var products = _context.Products.ToList();

            var Productsdemage = _context.Damegedproducts.Join
                (
                     _context.Products,

                      demag => demag.ProductId,
                      products => products.Id,


                     (demag, products) => new
                     {
                         demag,
                         products
                     }

                ).Join
                (
                  _context.ProductDetails,

                  p => p.demag.ProductId,
                  c => c.Products_Id,

                  (p, c) => new
                  {
                      id = p.demag.Id,
                      name = p.products.Name,
                      color = c.Color,
                      qty = p.demag.Qty
                  }
                  ).ToList();

            Console.WriteLine($"{Productsdemage}");


            ViewBag.products = products;
            ViewBag.damage = Productsdemage;


            return View();
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
