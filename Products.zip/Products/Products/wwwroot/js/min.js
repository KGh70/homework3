﻿

var gid;
function Test() {
    var x = document.getElementById("c1").value;

    console.log(x);

    var y = document.getElementById("p1");
    y.innerHTML = "أهلا وسهلا";


    window.location.href = "/test";
}


function ShowDelMessage(id) {
    gid = id;
    $('#confirm').modal('show');

}


function Confiremdel() {
    window.location.href = "/Home/Delete?record_no=" + gid;
}


function update(id)
{
    var gid = document.getElementById("Id")
    var name = document.getElementById("Name");
    var description = document.getElementById("Description");
    $.ajax({
        url: 'Home/GetData',
        type: 'POST',
        data: { id: id },

        success: function (result) {
            gid.value = result.id;
            name.value = result.name;
            description.value=result.description;
            console.table(result);
        }

    });

    $('#update').modal('show');



}


function Confiremdel1() {
    $.ajax({
        url: '/Home/Delete',
        type: 'POST',
        data: { record_no: gid },

        success: function (result) {

            window.location.href = "/Home";
        }



    });

}





var gid; // Global ID used by both delete and update functions

function showDeleteDetailDialog(id) {
    gid = id;
    $('#confirmDeleteDetail').modal('show');
}

function confirmDeleteDetail() {
    $.ajax({
        url: '/Home/DeleteDetails',
        type: 'POST',
        data: { id: gid },
        success: function (result) {
            window.location.reload(); // Reload the page to reflect the changes
        }
    });
}

function showUpdateDetailDialog(id) {
    $.ajax({
        url: '/Home/GetProductDetailData',  // Adjust if necessary
        type: 'GET',
        data: { id: id },
        success: function (result) {
            if (result) {
                $('#Id').val(result.id);
                $('#Products_Id').val(result.products_Id);
                $('#Price').val(result.price);
                $('#Qty').val(result.qty);
                $('#Color').val(result.color);
                $('#updateDetails').modal('show');
            } else {
                alert('No details found for the provided ID.');
            }
        },
        error: function (error) {
            alert("Error fetching details: " + error);
        }
    });
}





function AddNewDemag() {
    $('#demag').modal('show');
}


function submitDemagForm() {
    var formData = new FormData(document.getElementById('demagForm'));
    $.ajax({
        url: '/Home/AddDemag',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
            $('#demag').modal('hide');
            location.reload();  // Reload the whole page to update the table
        },
        error: function () {
            alert('Error saving damaged product.');
        }
    });
}


